# Source from any directory. Keep caches, temporary files and bytecode local.
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="$PROJECT_DIR/.deps:$PROJECT_DIR${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONDONTWRITEBYTECODE=1
export TMPDIR="$PROJECT_DIR/tmp"
export XDG_CACHE_HOME="$PROJECT_DIR/.cache"
export TORCH_HOME="$PROJECT_DIR/.cache/torch"
export CUDA_CACHE_PATH="$PROJECT_DIR/.cache/cuda"
export MPLCONFIGDIR="$PROJECT_DIR/.cache/matplotlib"
export OMP_NUM_THREADS=4
