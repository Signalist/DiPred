"""Check and time batching fixed-seed 20-frame diffusion samples."""
import sys,time,torch
from clean_reliability_common import ROOT,configure,manifest
from experiment_reliability_transport_e12 import geometry,history
sys.path.insert(0,str(ROOT/'github/DiPred'))
from reliability.selected16_predict import RequestedThreePredictor

@torch.no_grad()
def sample_batched(model,h,seeds):
    k=len(seeds);b=len(h)
    noises=[]
    for seed in seeds:
        gen=torch.Generator(device=h.device).manual_seed(seed)
        noises.append(torch.randn(h.shape,device=h.device,dtype=h.dtype,generator=gen))
    x=torch.stack(noises).reshape(k*b,*h.shape[1:])
    history=h.unsqueeze(0).expand(k,*h.shape).reshape(k*b,*h.shape[1:])
    for t in reversed(range(4)):
        alpha=model.abar[t]
        labels=torch.full((len(history),),t*33,device=h.device,dtype=torch.long)
        clean=model.net(x,labels,history)
        noise=(x-alpha.sqrt()*clean)/(1-alpha).sqrt()
        previous=model.abar[t-1] if t else x.new_tensor(1.)
        x=previous.sqrt()*clean+(1-previous).sqrt()*noise
    return x.reshape(k,b,*h.shape[1:])

configure();records=manifest()['files']['development']
p=RequestedThreePredictor(geometry(records),'selected16','cuda')
h=(history('development',0)-p.norm['mean'])/p.norm['std']
seeds=list(range(500000,500008))
torch.cuda.synchronize();start=time.time()
a=torch.stack([p.model.rollout(h,s,sign=1) for s in seeds])
torch.cuda.synchronize();serial=time.time()-start
for size in (2,4,8):
    torch.cuda.synchronize();start=time.time()
    b=torch.cat([sample_batched(p.model,h,seeds[i:i+size]) for i in range(0,len(seeds),size)])
    torch.cuda.synchronize();elapsed=time.time()-start
    print('SIZE',size,'seconds',elapsed,'serial',serial,'maxerr',float((a-b).abs().max()),flush=True)
