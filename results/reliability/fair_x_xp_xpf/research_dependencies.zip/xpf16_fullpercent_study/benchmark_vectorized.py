"""Development-only benchmark of independent head parameter batching."""
import time
import torch
from torch import nn
from functorch import combine_state_for_ensemble, vmap
from clean_reliability_common import configure
from experiment_selected16_quantile import new_head

configure()
class Wrapper(nn.Module):
    def __init__(self):
        super().__init__();self.head=new_head('compact16',None)
    def forward(self,base,last):
        return self.head.bounds(base,last,None,None,False)
models=[Wrapper() for _ in range(4)]
base=torch.randn(4,14,20,32,64,device='cuda')
last=torch.randn(4,48,32,64,device='cuda')
y=torch.randn(4,2,20,32,64,device='cuda')
levels=torch.tensor([.01,.02,.03,.04],device='cuda')
fmodel,params,buffers=combine_state_for_ensemble(models)
params=tuple(p.requires_grad_() for p in params)
def f(p,b):
    return fmodel(p,b,base,last)
for _ in range(2):
    lo,hi=vmap(f)(params,buffers);loss=((lo-y)**2+(hi-y)**2).mean();torch.autograd.grad(loss,params)
torch.cuda.synchronize();start=time.time()
for i in range(12):
    lo,hi=vmap(f)(params,buffers);loss=((lo-y)**2+(hi-y)**2).mean();torch.autograd.grad(loss,params)
torch.cuda.synchronize();batch=time.time()-start
for _ in range(2):
    lo,hi=models[0](base,last);torch.autograd.grad(((lo-y)**2+(hi-y)**2).mean(),models[0].parameters())
torch.cuda.synchronize();start=time.time()
for i in range(12):
    for model in models:
        lo,hi=model(base,last);torch.autograd.grad(((lo-y)**2+(hi-y)**2).mean(),model.parameters())
torch.cuda.synchronize();serial=time.time()-start
print('BATCH_SECONDS',batch,'SERIAL_SECONDS',serial,'SPEEDUP',serial/batch,flush=True)
